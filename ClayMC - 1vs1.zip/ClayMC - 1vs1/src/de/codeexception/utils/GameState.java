package de.codeexception.utils;

public enum GameState {

	Lobby,
	Ingame,
	Restarting
	
}
